
public enum QualityEncoding {
	Sanger,
	Illumina

}
