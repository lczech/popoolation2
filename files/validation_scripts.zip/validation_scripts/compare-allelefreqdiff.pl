use strict;
use warnings;


my $targetdiffile=shift;
my $pwcfile=shift;

my $targetdif=load_targetdif($targetdiffile);

open my $ifh,"<",$pwcfile or die "Could not open input file";


my($realdiscovered,$falsesnpcount,$notidentifiedcount)=(0,0,0);
my $falsediverences=[];
my $realdeviations=[];
while(<$ifh>)
{
    chomp;
    # ud        hit   ud      ud      ud      ud      ud      all       freq
    # 2R      11228   N       2       A/T     0       pop     T       0.130
    # 2R      11328   N       2       A/T     0       pop     A       0.120
    # 2R      11428   N       2       T/A     0       pop     T       0.120
    my(undef,$pos,undef,undef,undef,undef,undef,$char,$freqdif)=split /\t/,$_;
    
    if(exists($targetdif->{$pos}))
    {
        $targetdif->{$pos}{discovered}=1;
        $realdiscovered++;
        my $targetfreq=$targetdif->{$pos}{$char};
        print "COR\t$targetfreq\t$freqdif\n";
        push @$realdeviations,abs($targetfreq-$freqdif);
    }
    else
    {
        $falsesnpcount++;
        push @$falsediverences,$freqdif;
    }
}



while(my($pos,$snp)=each(%$targetdif))
{
    unless($snp->{discovered})
    {
        $notidentifiedcount++;
    }
}
print "STAT\treadldiscovered\t$realdiscovered\n";
print "STAT\tfalsediscovered\t$falsesnpcount\n";
print "STAT\tnotidentified\t$notidentifiedcount\n";


sub load_targetdif
{
    my $file=shift;
    open my $ifh,"<", $file or die "Could not open input file";
    
    my $targeth={};
    while(<$ifh>)
    {
        chomp;
        # 765400  T:0.5   G:0.5
        # 235931  C:0.22  G:0.22

        my($pos,$temp1,$temp2)=split /\t/,$_;
        my($c1,$f1)=split /:/,$temp1;
        my($c2,$f2)=split /:/,$temp2;
        $targeth->{$pos}={
            discovered=>0,
            $c1=>$f1,
            $c2=>$f2
        };
    }
    return $targeth;
    
}
