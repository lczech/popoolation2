#!/usr/bin/env python
import math

t=(2,1,3)
q=(0,10,20)
print t+q
