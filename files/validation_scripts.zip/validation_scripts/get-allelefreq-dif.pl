use strict;
use warnings;

my $allelefreqs1=shift;
my $allelefreqs2=shift;


my $al1=read_alleles($allelefreqs1);
my $al2=read_alleles($allelefreqs2);

while(my($pos,$snp1)=each(%$al1))
{
    my $snp2=$al2->{$pos};
    my $alkey=[keys(%{$snp1->{alleles}})];

    my @difar=();
    foreach my $char (@$alkey)
    {
        my $f1=$snp1->{alleles}{$char}{f};
        my $f2=$snp2->{alleles}{$char}{f};
        my $dif=abs($f1-$f2);
        push @difar, "$char:$dif";
    }
    my $toprint=join("\t",@difar);

    print "$pos\t$toprint\n"
    
}


sub read_alleles
{
    my $allele_file=shift;
    open my $ifh, "<", $allele_file or die "Could not open input file";
    my $alleleh={};
    
    while(<$ifh>)
    {
        chomp;
        my($pos,$refc,$c1,$co1,$c2,$co2)=split /\t/,$_;
        my $c1freq=$co1/($co1+$co2);
        my $c2freq=$co2/($co1+$co2);
        
        my $ah={};
        $ah->{$c1}={
            c=>$c1,
            f=>$c1freq
        };
        $ah->{$c2}={
            c=>$c2,
            f=>$c2freq
        };
        $alleleh->{$pos}={
            pos=>$pos,
            refc=>$refc,
            alleles=>$ah
        };
    }
    
    return $alleleh;
}