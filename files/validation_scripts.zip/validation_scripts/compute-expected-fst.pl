use strict;
use warnings;

use lib "/Users/robertkofler/dev/PopGenTools/Modules";
use Synchronized;


my $file=shift;
my $sp=get_basic_syncparser();

open my $ifh,"<", $file or die "Could not open output file"; 
while(<$ifh>)
{
    chomp;
    my $p=$sp->($_);
    my $fst=get_fst($p->{samples}[0],$p->{samples}[1]);
    print "$p->{chr}\t$p->{pos}\t$fst\n";
}


sub get_fst{
    my $p1=shift;
    my $p2=shift;
    my $cov1=$p1->{eucov};
    my $cov2=$p2->{eucov};
    
    my($a1,$t1,$c1,$g1)=($p1->{A}/$cov1, $p1->{T}/$cov1, $p1->{C}/$cov1, $p1->{G}/$cov1);
    my($a2,$t2,$c2,$g2)=($p2->{A}/$cov2, $p2->{T}/$cov2, $p2->{C}/$cov2, $p2->{G}/$cov2);
    my($aa,$ta,$ca,$ga)=(($a1+$a2)/2, ($t1+$t2)/2, ($c1+$c2)/2,($g1+$g2)/2);
    
    my $h1=het($a1,$t1,$c1,$g1);
    my $h2=het($a2,$t2,$c2,$g2);
    my $ht=het($aa,$ta,$ca,$ga);
    
    my $av=($h1+$h2)/2;
    
    my $fst=($ht-$av)/$ht;
    
    
    return $fst;
}

sub het
{
    my $af=shift;
    my $tf=shift;
    my $cf=shift;
    my $gf=shift;
    
    my $pi=1-$af**2-$tf**2-$cf**2-$gf**2;
    return $pi;
    
}